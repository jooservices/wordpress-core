<?php
/**
 * Plugin bootstrap.
 *
 * @package JOOservices\Resume
 */

declare(strict_types=1);

namespace JOOservices\Resume;

use JOOservices\Resume\Admin\CompanyEditor;
use JOOservices\Resume\Admin\CompanyList;
use JOOservices\Resume\Admin\ImportExport;
use JOOservices\Resume\Admin\Settings;
use JOOservices\Resume\Demo\DemoCommand;
use JOOservices\Resume\Frontend\Surfaces;
use JOOservices\Resume\Modules\CompanyDataModel;
use JOOservices\Resume\Modules\ProfileAndEditorialFields;
use JOOservices\Resume\PostTypes\Company;

/**
 * Checks the requirements and registers the components. It does not depend on the theme core.
 */
final class Plugin {

	public const VERSION = '0.1.0';
	public const MIN_PHP = '8.1';
	public const MIN_WP  = '6.6';

	/**
	 * Whether the components were registered.
	 *
	 * @var bool
	 */
	private static bool $booted = false;

	/**
	 * Whether the environment meets the requirements.
	 *
	 * @param string $php PHP version.
	 * @param string $wp  WordPress version.
	 */
	public static function meetsRequirements( string $php = PHP_VERSION, string $wp = '' ): bool {
		$wp = '' === $wp ? (string) get_bloginfo( 'version' ) : $wp;
		return version_compare( $php, self::MIN_PHP, '>=' ) && version_compare( $wp, self::MIN_WP, '>=' );
	}

	/**
	 * Activation: version and a one-time rewrite flush after the CPT exists.
	 */
	public static function activate(): void {
		update_option( 'joo_resume_version', self::VERSION );
		update_option( 'joo_resume_flush_rewrite', '1' );
	}

	/**
	 * Runs on plugins_loaded.
	 */
	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		if ( ! self::meetsRequirements() ) {
			add_action(
				'admin_notices',
				static function (): void {
					echo '<div class="notice notice-error"><p>' . esc_html(
						sprintf(
							/* translators: 1: PHP version, 2: WordPress version. */
							__( 'JOOservices Resume needs PHP %1$s and WordPress %2$s or newer and stays inactive.', 'jooservices-resume' ),
							self::MIN_PHP,
							self::MIN_WP
						)
					) . '</p></div>';
				}
			);
			return;
		}
		self::$booted = true;
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			DemoCommand::register();
		}
		add_action( 'init', array( self::class, 'loadTextDomain' ), 1 );
		add_action( 'init', array( self::class, 'register' ), 5 );
		add_action( 'init', array( self::class, 'maybeFlushRewrites' ), 99 );
	}

	/**
	 * Loads translations.
	 */
	public static function loadTextDomain(): void {
		load_plugin_textdomain( 'jooservices-resume', false, dirname( plugin_basename( JOO_RESUME_FILE ) ) . '/languages' );
	}

	/**
	 * Registers every component.
	 */
	public static function register(): void {
		( new Company() )->hook();
		( new CompanyDataModel() )->hook();
		( new Surfaces() )->hook();
		if ( is_admin() ) {
			( new CompanyEditor() )->hook();
			( new CompanyList() )->hook();
			( new Settings() )->hook();
			( new ImportExport() )->hook();
		}
		( new ProfileAndEditorialFields() )->hook();
	}

	/**
	 * Flushes the rewrite rules once after activation.
	 */
	public static function maybeFlushRewrites(): void {
		if ( '1' === get_option( 'joo_resume_flush_rewrite' ) ) {
			delete_option( 'joo_resume_flush_rewrite' );
			flush_rewrite_rules( false );
		}
	}
}
